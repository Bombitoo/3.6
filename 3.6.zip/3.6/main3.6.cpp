#include <stdio.h>

main()
{
 for(int i=5;i<11;i++)
 {
   printf("5*%i\n",i);
 }     
}
